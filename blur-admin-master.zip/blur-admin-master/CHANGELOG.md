v1.3.1 - 15 Dec 2016
--------------------
- Fix gulp build
- Update dependencies
- Fix datepicker position

v1.3.0 - 10 Dec 2016
--------------------
- Update bower dependencies
- Add progress dialog component
- Add datepicker component
- Scroll up pages upon navigation
- CSS-only switchers
- Use ui-select instead of bootstrap-select

v1.2.0 - 16 May 2016
--------------------
- Refactoring to improve customization, fixes #22, #26
- Add documentation
- Sidebar refactoring, fixes #14, #15, #27
- Bootstrap select refactoring #18

v1.1.1 - 11 Apr 2016
--------------------
- Improved scrolling performance, fixes #2
- Set 0.9.5 version for the Chartist library by default, fixes #5
